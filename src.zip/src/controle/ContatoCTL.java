/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;
import java.util.ArrayList;
import modelos.*;
import persistencia.ContatoDAO;

public class ContatoCTL implements IcrudContato{
  ContatoDAO persistenciaContatoDAO = null;

  public ContatoCTL() {
    persistenciaContatoDAO = new ContatoDAO();
  }
  
  private void verificarDadosContato(Contato objeto) throws Exception{
    String resposta = "";
    if(objeto.getIdContato() <= 0) 
      resposta += "\nValor do identificador não pode ser <= 0";
    if(objeto.getNomeCompleto().isEmpty())
      resposta += "\nNome esta vazio";
    if(objeto.getEmail().isEmpty())
      resposta += "\nEmail esta vazio";
    if(!resposta.isEmpty()) throw new Exception(resposta);
  }

  @Override
  public void incluir(Contato objeto) throws Exception {
    try {
      verificarDadosContato(objeto);
      if(buscarID(objeto.getIdContato())!=null)
        throw new Exception("Identificador Já Existe");
      persistenciaContatoDAO.incluir(objeto);
    } catch (Exception erro) {
      throw new Exception("Controle - Incluir "+erro.getMessage());
    }
  }

  @Override
  public void excluir(int idContato) throws Exception {
    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
  }

  @Override
  public void alterar(Contato objeto) throws Exception {
    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
  }

  @Override
  public Contato consultar(String nomeCompleto) throws Exception {
    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
  }

  @Override
  public Contato buscarID(int idContato) throws Exception {
    return persistenciaContatoDAO.buscarID(idContato);  
  }

  @Override
  public ArrayList<Contato> listagemDeContatos() throws Exception {
    return persistenciaContatoDAO.listagemDeContatos();
  }
    
    
}
