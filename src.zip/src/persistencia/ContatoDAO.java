/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;
import modelos.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
/**
 *
 * @author ejmcc
 */
public class ContatoDAO implements IcrudContato{
  //Atributos
  String nomeDoArquivoNoDisco = null;
  //Metodo Construtor
  public ContatoDAO(){
    nomeDoArquivoNoDisco = "./src/bancodedados/contadosBD.txt";
  }
  //Metodos Sobrecarregados
  @Override
  public void incluir(Contato objeto) throws Exception {
    try{
      //cria o arquivo
      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco,true);
      //Criar o buffer do arquivo
      BufferedWriter bw =new BufferedWriter(fw);
      //Escreve no arquivo
      String str = objeto.getIdContato() + "";
      str += ";"+ objeto.getNomeCompleto();
      str += ";" + objeto.getEmail();
      bw.write(str+"\n");
      //fecha o arquivo
      bw.close();		
    }catch(Exception erro){
      String msg = "Metodo Incluir Contato - "+erro.getMessage();
      throw new Exception(msg);
    }  
  }

  @Override
  public void excluir(int idContato) throws Exception {  
    try{
      ArrayList<Contato> listagem = null;
      listagem = this.listagemDeContatos();
      //cria o arquivo
      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco);
      //Criar o buffer do arquivo
      BufferedWriter bw =new BufferedWriter(fw);
      for(Contato obj : listagem){
        if(obj.getIdContato() != idContato){
          String str = obj.getIdContato() + "";
          str += ";"+ obj.getNomeCompleto();
          str += ";" + obj.getEmail();
          bw.write(str+"\n");
        }
      }
      bw.close();
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Excluir - "+erro.getMessage();
      throw new Exception(msg);
    } 
  }

  @Override
  public void alterar(Contato objeto) throws Exception {  
    try {
      ArrayList<Contato> listagem = null;
      listagem = this.listagemDeContatos();
      //cria o arquivo
      FileWriter fw = new FileWriter(nomeDoArquivoNoDisco);
      //Criar o buffer do arquivo
      BufferedWriter bw =new BufferedWriter(fw);
      for(Contato obj : listagem){
        if(obj.getIdContato() == objeto.getIdContato()){
          String str = objeto.getIdContato() + "";
          str += ";"+ objeto.getNomeCompleto();
          str += ";" + objeto.getEmail();
          bw.write(str);
        }else{
          String str = obj.getIdContato() + "";
          str += ";"+ obj.getNomeCompleto();
          str += ";" + obj.getEmail();
          bw.write(str);
        }
      }
      bw.close();
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Atualizar - "+erro.getMessage();
      throw new Exception(msg);
    } 
  }

  @Override
  public Contato consultar(String nomeCompleto) throws Exception {
    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
  }

  @Override
  public ArrayList<Contato> listagemDeContatos() throws Exception {
    try{
      ArrayList<Contato> listaDeContatos = new ArrayList<>();
      FileReader fr = new FileReader(nomeDoArquivoNoDisco);
      BufferedReader br  = new BufferedReader(fr);
      String linha = "";
      while((linha=br.readLine())!=null){
        String vetorStr[] = linha.split(";");
        int idContato = Integer.parseInt(vetorStr[0]);
        String nomeCompleto = vetorStr[1];
        String email = vetorStr[2];
        Contato objetoContato = new Contato(idContato,nomeCompleto,email);
        listaDeContatos.add(objetoContato);
      }
      br.close();
      return listaDeContatos;
    }catch(Exception erro){
      throw erro;
    }   
  }

  @Override
  public Contato buscarID(int idContato) throws Exception {
    try{
      //abrir um arquivo existente
      FileReader fr = new FileReader(nomeDoArquivoNoDisco);
      //Criar o buffer do arquivo
      BufferedReader br  = new BufferedReader(fr);
      String linha = "";
      while((linha=br.readLine())!=null){
        String vetorStr[] = linha.split(";");
        int idContatoAux = Integer.parseInt(vetorStr[0]);
        if(idContatoAux == idContato){
          String nome = vetorStr[1];
          String email = vetorStr[2];
          Contato objContato = null;
          objContato = new Contato(idContatoAux,nome,email);
          br.close();
          return objContato;
        }
      }
      br.close();
      return null;
    }catch(Exception erro){
      String msg = "Persistencia - Metodo Buscar - "+erro.getMessage();
      throw new Exception(msg);
    }     
  } 
}
